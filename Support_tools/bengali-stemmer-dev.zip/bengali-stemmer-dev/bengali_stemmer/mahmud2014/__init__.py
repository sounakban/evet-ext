from .verb import stem_verb
